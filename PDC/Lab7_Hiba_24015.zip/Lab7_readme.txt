To run Lab 7, run the following commands in the terminal: 
(You can change the number of MPI processers used to execute this lab. I used 2 MPI processors)

mpicc -o lab7 lab7final.c
mpirun -np 2 ./lab7

In my executation of the cluster computing vector dot product, I used a data size 10000000 due to CoCalc's resource allocation limits